<?php

if(!isset($_COOKIE['clup'])){
	
	header('location: ../');
	
}

setcookie('clup', null ,time() - 36000000 , '/');

header('location: ../');