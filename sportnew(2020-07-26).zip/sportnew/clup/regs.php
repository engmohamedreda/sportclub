<?php

include("../connect.php");

if(!isset($_COOKIE['clup'])){
	
	header('location: ../');
}

$clup = $_COOKIE['clup'];

$sql = "select * from clup where id = '{$clup}'";

$query = mysqli_query($connect,$sql);

if(mysqli_num_rows($query) != 1){
	
	header('location: ../');
	
}

$my = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>sign In</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="imageslogin/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fontslogin/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fontslogin/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendorlogin/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendorlogin/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../csslogin/util.css">
	<link rel="stylesheet" type="text/css" href="../csslogin/main.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/mobile.css">
<!--===============================================================================================-->
</head>
<body >
	<div id="header">
		<h1><a href="index.html">نظام حجز الالعاب الرياضية</a></h1>
		<ul id="navigation">
			
			<li class="">
				<a href="out.php">تسجيل خروج</a>
			</li>
			<li class="current">
				<a href="regs.php">طلبات التسجيل</a>
			</li>
			<li>
				<a href="clubs.php">الاندية</a>
			</li>
			
			<li>
				<a href="./">بياناتى</a>
			</li>
			
		</ul>
	</div>
	
	<div id="body">
		<span class="login100-form-title p-b-26">
			طلبات التسجيل للانشطة
		</span>
		<p>
			<table class="table text-right">
				<tr>
					<th class="text-right">اللاعب</th>
					<th class="text-right">النشاط</th>
					<th class="text-right">حذف</th>
				</tr>

				<?php
				
				if(isset($_GET['del'])){
					
					$del = $_GET['del'];
					
					$sql = "delete from registration where id = '{$del}'";
					
					mysqli_query($connect,$sql);
					
					header('location: '.$_SERVER['PHP_SELF']);
					
				}

				$sql = "select * from registration where clup = '{$my['id']}' and activity is not null";
				
				$query = mysqli_query($connect,$sql);
				
				while($result = mysqli_fetch_assoc($query)){
					$player = mysqli_fetch_array(mysqli_query($connect, "select * from `player` where `id` = '{$result['player']}'"));
					$activity = mysqli_fetch_array(mysqli_query($connect, "select * from `activity` where `id` = '{$result['activity']}'"));
				?>
				<tr>
					<td><?= $player['name'] ?></td>
					<td><?= $activity['name'] ?></td>
					<td><a href="<?= $_SERVER['PHP_SELF'] ?>?del=<?= $result['id'] ?>" class="btn btn-danger">حذف</a></td>
				</tr>
				<?php
				}
				?>
			</table>
		</p>
		<span class="login100-form-title p-b-26">
			طلبات التسجيل للالعاب
		</span>
		<p>
			<table class="table text-right">
				<tr>
					<th class="text-right">اللاعب</th>
					<th class="text-right">اللعبة</th>
					<th class="text-right">حذف</th>
				</tr>

				<?php
				
				$sql = "select * from registration where clup = '{$my['id']}' and game is not null";
				
				$query = mysqli_query($connect,$sql);
				
				while($result = mysqli_fetch_assoc($query)){
					$player = mysqli_fetch_array(mysqli_query($connect, "select * from `player` where `id` = '{$result['player']}'"));
					$game = mysqli_fetch_array(mysqli_query($connect, "select * from `game` where `id` = '{$result['game']}'"));
				?>
				<tr>
					<td><?= $player['name'] ?></td>
					<td><?= $game['name'] ?></td>
					<td><a href="<?= $_SERVER['PHP_SELF'] ?>?del=<?= $result['id'] ?>" class="btn btn-danger">حذف</a></td>
				</tr>
				<?php
				}
				?>
			</table>
		</p>
	</div>
	<div id="footer">
		<div>
			
			<p>
				&copy; 2023 by system team . All rights reserved.
			</p>
		</div>
		<div id="connect">
			<a href="https://www.facebook.com" id="facebook" target="_blank">Facebook</a>
			<a href="https://www.twitter.com" id="twitter" target="_blank">Twitter</a>
			<a href="https://www.googleplus.com" id="googleplus" target="_blank">Google&#43;</a>
			
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="../vendorlogin/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/bootstrap/js/popper.js"></script>
	<script src="../vendorlogin/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/daterangepicker/moment.min.js"></script>
	<script src="../vendorlogin/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="../jslogin/main.js"></script>

</body>
</html>
