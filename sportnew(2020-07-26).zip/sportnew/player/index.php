<?php

include("../connect.php");

if(!isset($_COOKIE['player'])){
	
	header('location: ../');
}

$player = $_COOKIE['player'];

$sql = "select * from player where id = '{$player}'";

$query = mysqli_query($connect,$sql);

if(mysqli_num_rows($query) != 1){
	
	header('location: ../');
	
}

$my = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>sign In</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="imageslogin/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fontslogin/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fontslogin/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendorlogin/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendorlogin/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../csslogin/util.css">
	<link rel="stylesheet" type="text/css" href="../csslogin/main.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/mobile.css">
<!--===============================================================================================-->
</head>
<body >
	<div id="header">
		<h1><a href="index.html">نظام حجز الالعاب الرياضية</a></h1>
		<ul id="navigation">
			
			<li class="">
				<a href="out.php">تسجيل خروج</a>
			</li>
			<li class="">
				<a href="regs.php">طلبات التسجيل</a>
			</li>
			<li>
				<a href="clubs.php">الاندية</a>
			</li>
			
			<li class="current">
				<a href="./">بياناتى</a>
			</li>
		</ul>
	</div>
	
	<div id="body">
		<span class="login100-form-title p-b-26">
			بياناتى
		</span>
		<p>
			<table class="table text-right">
				<tr>
					<td>الاسم</td>
					<td><?= $my['name'] ?></td>
				</tr>
				<tr>
					<td>الايميل</td>
					<td><?= $my['email'] ?></td>
				</tr>
			</table>
		</p>
	</div>
	<div id="footer">
		<div>
			
			<p>
				&copy; 2023 by system team . All rights reserved.
			</p>
		</div>
		<div id="connect">
			<a href="https://www.facebook.com" id="facebook" target="_blank">Facebook</a>
			<a href="https://www.twitter.com" id="twitter" target="_blank">Twitter</a>
			<a href="https://www.googleplus.com" id="googleplus" target="_blank">Google&#43;</a>
			
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="../vendorlogin/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/bootstrap/js/popper.js"></script>
	<script src="../vendorlogin/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/daterangepicker/moment.min.js"></script>
	<script src="../vendorlogin/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="../jslogin/main.js"></script>

</body>
</html>
