<?php

include("../connect.php");

if(!isset($_COOKIE['admin'])){
	
	header('location: ../');
}

$admin = $_COOKIE['admin'];

$sql = "select * from admin where id = '{$admin}'";

$query = mysqli_query($connect,$sql);

if(mysqli_num_rows($query) != 1){
	
	header('location: ../');
	
}

$my = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>sign In</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="imageslogin/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fontslogin/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fontslogin/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendorlogin/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendorlogin/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendorlogin/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../csslogin/util.css">
	<link rel="stylesheet" type="text/css" href="../csslogin/main.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/mobile.css">
<!--===============================================================================================-->
</head>
<body >
	<div id="header">
		<h1><a href="index.html">نظام حجز الالعاب الرياضية</a></h1>
		<ul id="navigation">
			
			<li class="">
				<a href="out.php">تسجيل خروج</a>
			</li>
			<li class="current">
				<a href="clubs.php">النوادى الرياضية</a>
			</li>
			
			<li>
				<a href="./">بياناتى</a>
			</li>
		</ul>
	</div>
	
	<div id="body">
		<span class="login100-form-title p-b-26">
			النوادى الرياضية
		</span>
		<p>
		<form class="login100-form validate-form" method="post">
			<span class="login100-form-title p-b-26">
				اضافة جديد
			</span>
			<div class="wrap-input100">
			<?php

				if(isset($_GET['del'])){
					
					$del = $_GET['del'];
					
					$sql = "delete from clup where id = '{$del}'";
					
					mysqli_query($connect,$sql);
					
					header('location: '.$_SERVER['PHP_SELF']);
					
				}

				if(isset($_POST['login'])){
					
					if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password']) ||
						empty($_POST['confirm-password'])){
						
						echo 'كل الخانات اجبارية';
						
					}else{
						
						if($_POST['confirm-password'] != $_POST['password']){
							
							echo 'كلمة السر غير متطابقة';
							
						}else{
						
							$sql = "select * from clup where email = '{$_POST['email']}'";
							
							$count = mysqli_num_rows( mysqli_query($connect,$sql) );
							
							if($count != 0){
								
								echo 'الايميل مسجل مسبقا';
								
							}else{
							
								$sql = "INSERT INTO `clup`(`name`, `email`, `password`, `admin`)
								VALUES('{$_POST['name']}','{$_POST['email']}','{$_POST['password']}', '{$my['id']}')";
								
								if(mysqli_query($connect,$sql)){
									
									echo 'تم التسجيل بنجاح';
									
								}else{
									
									echo 'خطأ فى التسجيل';
									
								}
								
							}
							
						}
						
					}
					
				}

			?>
							
			</div>
			<div class="wrap-input100">
				<input class="input100" type="text" name="email">
				<span class="focus-input100" data-placeholder="البريد الالكتروني"></span>
			</div>

			<div class="wrap-input100">
				<input class="input100" type="text" name="name">
				<span class="focus-input100" data-placeholder="الاسم"></span>
			</div>

			<div class="wrap-input100 validate-input" data-validate="Enter password">
				<span class="btn-show-pass">
					<i class="zmdi zmdi-eye"></i>
				</span>
				<input class="input100" type="password" name="password">
				<span class="focus-input100" data-placeholder="كلمة المرور"></span>
			</div>

			<div class="wrap-input100 validate-input" data-validate="Enter password">
				<span class="btn-show-pass">
					<i class="zmdi zmdi-eye"></i>
				</span>
				<input class="input100" type="password" name="confirm-password">
				<span class="focus-input100" data-placeholder="تاكيد كلمة المرور"></span>
			</div>

			<div class="container-login100-form-btn">
				<div class="wrap-login100-form-btn">
					<div class="login100-form-bgbtn"></div>
					<button class="login100-form-btn" type="submit" name="login">
						 حفظ
					</button>
				</div>
			</div>

		</form>
				<hr>
			<table class="table text-right">
				<tr>
					<th class="text-right">الاسم</th>
					<th class="text-right">البريد</th>
					<th class="text-right">حذف</th>
				</tr>

				<?php
				
				$sql = "select * from clup";
				
				$query = mysqli_query($connect,$sql);
				
				while($result = mysqli_fetch_assoc($query)){
				?>
				<tr>
					<td><?= $result['name'] ?></td>
					<td><?= $result['email'] ?></td>
					<td><a href="<?= $_SERVER['PHP_SELF'] ?>?del=<?= $result['id'] ?>" class="btn btn-danger">حذف</a></td>
				</tr>
				<?php
				}
				?>
			</table>
		</p>
	</div>
	<div id="footer">
		<div>
			
			<p>
				&copy; 2023 by system team . All rights reserved.
			</p>
		</div>
		<div id="connect">
			<a href="https://www.facebook.com" id="facebook" target="_blank">Facebook</a>
			<a href="https://www.twitter.com" id="twitter" target="_blank">Twitter</a>
			<a href="https://www.googleplus.com" id="googleplus" target="_blank">Google&#43;</a>
			
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="../vendorlogin/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/bootstrap/js/popper.js"></script>
	<script src="../vendorlogin/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/daterangepicker/moment.min.js"></script>
	<script src="../vendorlogin/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="../vendorlogin/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="../jslogin/main.js"></script>

</body>
</html>
