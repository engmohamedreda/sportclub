<?php

if(!isset($_COOKIE['admin'])){
	
	header('location: ../');
	
}

setcookie('admin', null ,time() - 36000000 , '/');

header('location: ../');